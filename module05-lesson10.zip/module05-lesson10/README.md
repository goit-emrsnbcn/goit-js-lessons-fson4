# GoIT JavaScript Lessons Summary

## Module 5 Lesson 10 (Prototypes and Classes)

-   Object-Oriented Programming
-   Prototypal Inheritance
-   Classes

### JS Tasks:

-   Example 1 - Blogger
-   Example 2 - Storagе
-   Example 3 - User
-   Example 4 - Notes
