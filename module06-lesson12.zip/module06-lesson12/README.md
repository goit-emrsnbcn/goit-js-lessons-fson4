# GoIT JavaScript Lessons Summary

## Module 6 Lesson 12 (Events)

-   Events
-   Event Object
-   Keyboard Events
-   Form Events

### JS Examples:

-   Example 1 ('Click' event & event.target/currentTarget)
-   Example 2 ('Submit' event on forms)
-   Example 3 ('This' on event listeners, 'Keydown' event & removeEventListener method)
-   Example 4 (Modal Window)
