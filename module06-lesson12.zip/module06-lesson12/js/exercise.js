let box1 = document.getElementById("box1");

box1.addEventListener("click", function () {
	let color = prompt("Type a color");
});
