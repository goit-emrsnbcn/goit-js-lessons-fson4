const BASE_URL = "https://newsapi.org/v2/everything";
const API_KEY = "6751ad3df7d343859c1afe420864ea35";

export function getNews() {
	const url = `${BASE_URL}`;
}
