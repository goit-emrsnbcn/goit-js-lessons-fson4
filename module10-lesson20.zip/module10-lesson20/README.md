# GoIT JavaScript Lessons Summary

## Module 10 Lesson 20 (Pagination)

-   Pagination

### JS Examples:

-   Example 1 - Pagination using Load More button
